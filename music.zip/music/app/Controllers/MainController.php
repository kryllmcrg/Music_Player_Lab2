<?php

namespace App\Controllers;

use App\Controllers\BaseController;
class MainController extends BaseController
{
    private $playlist;

    public function __construct()
    {
        $this->playlist = new \App\Models\PlaylistModel();
    }
    public function index()
    {
        //
    }
    public function view()
    {
        $data = [
            'playlist' => $this->playlist->findAll(),
        ];
        return view('view', $data);
    }
    public function createPlaylist(){
        $data = [
            'name' => $this->request->getVar('pname'),
        ];
        $this->playlist->save($data);
        return redirect()->to('/view');
    }
}