<?php

namespace App\Controllers;

use App\Models\MusicModel;
use App\Models\PlaylistModel;
use App\Models\PlaylistMusicModel;
use App\Controllers\BaseController;

class MainController extends BaseController
{
    public function test()
    {
        $j = new MusicModel();
        $data['main'] = $j ->findAll();
        //var_dump($data);

        return view('main', $data);
    }
    
    private $music;
    private $playlists;
    private $playlistmusic;

    public function __construct()
    {
       $this->music = new MusicModel();
       $this->playlists = new PlaylistModel();
       $this->playlistmusic = new PlaylistMusicModel();
    }
    public function index()
    {
        $data['music'] = $this->music->findAll();
        $data['playlists'] = $this->playlists->findAll();
        return view('player',$data);
    }
    public function create()
    {
        $data =[
            'name' => $this->request->getPost('name')
        ];
        $this->playlists->insert($data);
        return redirect()->to('/player');
    }
    public function playlists($id)
    {
        $playlists = $this->playlists->find($id);

        if($playlists) 
        {
            $playlistmusic = $this->playlistmusic->where('playlist_id',$id)->findAll();
            $music = [];
            foreach ($playlistmusic as $playlistmusic) {
                $musicItem = $this->music->find(playlistsmusic['playlist_id']);
                if ('musicItem'){
                    $music[] = $musicItem;
                }
        }
        $data = [
            'playlists' => $playlists,
            'music' => $music,
            'playlists' =>$this->playlists->findAll(),
            'playlistsmusic' => $playlistmusic,
        ];
        return view('player', $data); 
        } else{
            return redirect()->to('/player');
        }
    } 
    public function upload()
    {
        $file = $this->request->getFile('file');
        $title = $this->request->getFile('title');
        $artist = $this->request->getFile('artist');
        $newName = $title . '_' . $artist . '_' . 'mp3';
        $file->move(ROOTPATH . 'public/' , $newName);
        $data = [
            'title' => $title,
            'arstist' => $artist,
            'file_path' => $newName
        ];
        $this->music->insert($data);
        return redirect()->to('/player');
    }
}
