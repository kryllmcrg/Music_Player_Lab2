<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\PlaylistModel;
class MainController extends BaseController
{
    private $playlist;

    public function __construct()
    {
        $this->playlist = new \App\Models\PlaylistModel();
    }
    public function index()
    {
        //
    }
    public function view()
    {
        $data = [
            'playlist' => $this->playlist->findAll(),
        ];
        return view('view');
    }
    public function createPlaylist(){
        $data = [
            'name' => $this->request->getVar('pname'),
        ];
        $this->playlist->save($data);
        return redirect()->to('/view');
    }
}